<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MissionLocation extends Model
{
    protected $guarded = [];
    protected $table = 'mission_locations';
}
